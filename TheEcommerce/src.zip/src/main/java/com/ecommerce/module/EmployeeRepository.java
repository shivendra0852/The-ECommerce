package com.ecommerce.module;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.ecommerce.entity.Address;
import com.ecommerce.entity.Employee;

import jakarta.transaction.Transactional;

public interface EmployeeRepository extends JpaRepository<Employee, Integer>{
	Optional<Employee> findByEmail(String email);
	
	@Modifying
	@Transactional
	@Query("UPDATE Employee e SET e.salary = e.salary + ?2 WHERE e.performanceScore > ?1")
	public List<Employee> updateSalaryOfEmployees(Double performanceScore, Double salary);
	
	@Modifying
	@Transactional
	@Query("DELETE FROM Address a WHERE a.employee.id IN ?1 AND a.employee.hasCar = true")
	public void deleteAddressOfEmployees(List<Integer> employeeIds);
	
	@Modifying
	@Transactional
	@Query("INSERT into Employee (name, age, joiningDate) values(?1, ?2, ?3)")
	public Employee registerEmployeeQuery(String name, Integer age, Date joiningDate);
	
	@Query("SELECT e.age FROM Address a JOIN a.employee e WHERE e.name LIKE %?1 AND e.age > ?2 AND e.hasCar = true AND a.city IN ?3")
	List<Integer> fetchAgesOfEmployees(String nameEndsWith, Integer age, List<String> cities);
	
	@Query("SELECT a from Address a JOIN a.employee e WHERE a.state = ?1 AND a.pincode IN ?2 AND e.performanceScore > ?3 AND e.annualPackage = ?4 AND e.joiningDocumentSubmitted = true AND e.joiningDate BETWEEN ?5 AND ?6")
	List<Address> fetchAddressesOfEmployees(String state, List<String> pincodes, Double performanceScore, Double annualPackage, String startDate, String endDate);

}
