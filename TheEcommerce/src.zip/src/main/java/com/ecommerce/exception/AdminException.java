package com.ecommerce.exception;

@SuppressWarnings("serial")
public class AdminException extends RuntimeException{
	public AdminException() {
		
	}
	
	public AdminException(String message) {
		super(message);
	}
}
