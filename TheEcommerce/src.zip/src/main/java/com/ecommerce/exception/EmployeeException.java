package com.ecommerce.exception;

@SuppressWarnings("serial")
public class EmployeeException extends RuntimeException{
	
	public EmployeeException() {
		// TODO Auto-generated constructor stub
	}
	
	public EmployeeException(String message) {
		super(message);
	}
}
