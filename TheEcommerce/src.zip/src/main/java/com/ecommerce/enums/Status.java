package com.ecommerce.enums;

public enum Status {
	PENDING,APPROVED;
}
